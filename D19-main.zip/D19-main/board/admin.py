from django.contrib import admin
from .models import *

admin.site.register(Users)
admin.site.register(Posts)
admin.site.register(Categories)
admin.site.register(Comment)



# Register your models here.
